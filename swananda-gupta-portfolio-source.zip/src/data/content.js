// Domain color coding used throughout: security = cyan, ai/research = violet, software = amber
export const DOMAIN = {
  security: { name: "Security", color: "#5EEAD4", soft: "#5EEAD422" },
  research: { name: "AI / Research", color: "#A78BFA", soft: "#A78BFA22" },
  software: { name: "Software", color: "#FFB454", soft: "#FFB45422" },
};

export const PROFILE = {
  name: "Swananda Gupta",
  tagline: "Reading signals — from brainwaves to network traffic — and building the systems that act on them.",
  affiliation: "CSE Undergraduate, VIT Chennai",
  focus: ["AI / ML", "Cybersecurity", "Quantum ML", "Full-Stack"],
  bio: "I'm a Computer Science and Engineering undergraduate at VIT Chennai, working across AI-driven applications, quantum machine learning, digital twins, IoT systems, and enterprise software. I like taking research out of the lab and into something that runs — instrumenting systems, reading the signals they produce, and closing the loop between analysis and action.",
  links: {
    linkedin: "https://www.linkedin.com/in/swananda-gupta-107a36323/",
    github: "https://github.com/swanandagupta",
  },
};

export const COMPETENCIES = [
  "Artificial Intelligence",
  "Machine Learning",
  "Quantum Computing",
  "Cybersecurity",
  "Full-Stack Development",
  "Enterprise Software",
  "Digital Twin Systems",
  "IoT",
  "Research & Innovation",
  "Computer Vision",
  "Technical Leadership",
  "System Design",
];

export const EXPERIENCE = [
  {
    domain: "research",
    role: "Research Intern",
    org: "Vellore Institute of Technology",
    period: "2026 — Present",
    summary:
      "Researching EEG biometrics and quantum machine learning for robust identity recognition.",
    details: [
      "Working title: Manifold-Aware Identity–State Disentanglement for Cross-Paradigm EEG Biometric Identification — a Riemannian and quantum-enhanced comparative study.",
      "Proposed a hybrid Riemannian + quantum learning framework and an identity-state disentanglement architecture.",
      "Compared classical manifold learning against quantum-enhanced classification to improve the robustness of EEG biometric authentication.",
    ],
    tags: ["EEG Biometrics", "Riemannian Geometry", "Variational Quantum Classifier", "Cognitive Fingerprinting"],
  },
  {
    domain: "security",
    role: "SOC Analyst Intern",
    org: "Maharashtra Cyber Headquarters",
    period: "Jun 2026 — Jul 2026",
    summary:
      "Monitored live security feeds and triaged incidents on a state cyber operations desk.",
    details: [
      "Ran security monitoring and log analysis in IBM QRadar SIEM.",
      "Performed threat detection and incident triage mapped against MITRE ATT&CK.",
      "Supported CERT incident response and threat investigation workflows.",
    ],
    tags: ["IBM QRadar", "SIEM", "MITRE ATT&CK", "Incident Response"],
  },
  {
    domain: "software",
    role: "Web & Game Developer Intern",
    org: "Council of Scientific & Industrial Research (CSIR)",
    period: "Oct 2024 — Aug 2025",
    summary:
      "Built AI-driven learning platforms that turn cognitive-science concepts into adaptive games.",
    details: [
      "Developed responsive interfaces with React and Tailwind CSS.",
      "Integrated adaptive game mechanics informed by cognitive science.",
      "Built real-time analytics dashboards to track learner progress.",
    ],
    tags: ["React", "Tailwind CSS", "Adaptive Systems", "Analytics"],
  },
  {
    domain: "software",
    role: "Software Developer Intern",
    org: "Larsen & Toubro (L&T)",
    period: "May 2025 — Jul 2025",
    summary:
      "Shipped enterprise features on an ASP.NET Core platform used across engineering teams.",
    details: [
      "Built on ASP.NET Core MVC with Onion Architecture and JWT authentication.",
      "Delivered AI-powered manuals, PDF generation, and drag-and-drop interfaces.",
      "Optimized performance with Entity Framework and SQL Server, and added client-side storage with IndexedDB.",
    ],
    tags: ["ASP.NET Core", "Onion Architecture", "Entity Framework", "SQL Server"],
  },
];

export const PROJECTS = [
  {
    domain: "security",
    title: "SOC Copilot",
    description:
      "An AI-assisted SOC analyst copilot that streamlines threat investigation, log analysis, and incident-response workflows.",
    impact: "Faster investigation turnaround",
    tags: ["IBM QRadar", "SIEM", "MITRE ATT&CK", "Python"],
  },
  {
    domain: "security",
    title: "Auto-Pentesting Agentic AI",
    description:
      "An autonomous penetration-testing framework where LLM-driven agents reason through endpoint scans to find vulnerabilities.",
    impact: "100+ endpoints scanned · 60% less manual effort",
    tags: ["Python", "FastAPI", "LLMs", "Agentic AI"],
    highlights: ["SQL injection detection", "Cross-site scripting (XSS) detection", "Authentication flaw detection"],
  },
  {
    domain: "research",
    title: "Streeva",
    description:
      "An AI-powered women's safety platform built around a digital twin of the city — modeling risk before it happens.",
    impact: "Real-time journey monitoring",
    tags: ["Python", "FastAPI", "Firebase", "Machine Learning"],
    highlights: ["High-risk zone prediction", "Safe route recommendation", "Automated emergency assistance"],
  },
  {
    domain: "security",
    title: "SecureSphere",
    description:
      "A machine-learning intrusion detection system that watches network traffic and flags threats in real time.",
    impact: "92% detection accuracy · trained on CICIDS 2019",
    tags: ["Python", "Flask", "Scikit-learn", "NumPy"],
  },
  {
    domain: "research",
    title: "Smart Environmental Monitoring System",
    description:
      "An IoT platform that fuses gas-sensor and GPS data to detect environmental anomalies and raise intelligent alerts.",
    impact: "Predictive anomaly alerting",
    tags: ["ESP32", "Python", "IoT Sensors"],
  },
];

export const SKILLS = [
  {
    label: "Programming Languages",
    items: ["Python", "Java", "JavaScript", "C", "C++", "C#", "SQL"],
  },
  {
    label: "Frameworks & Libraries",
    items: ["ASP.NET Core MVC", "React", "Tailwind CSS", "Flask", "Entity Framework", "Scikit-learn", "PyTorch", "OpenCV"],
  },
  {
    label: "Databases",
    items: ["SQL Server", "MongoDB", "Firebase"],
  },
  {
    label: "AI & Machine Learning",
    items: ["Deep Learning", "Computer Vision", "Large Language Models", "Predictive Modeling", "AI Agents", "Quantum Machine Learning"],
  },
  {
    label: "Cybersecurity",
    items: ["IBM QRadar", "SIEM", "Threat Detection", "Incident Triage", "MITRE ATT&CK", "CERT Workflows", "Log Analysis"],
  },
  {
    label: "Cloud & Development",
    items: ["AWS", "Git", "REST APIs", "FastAPI", "Node.js"],
  },
];

export const RESEARCH_INTERESTS = [
  "Artificial Intelligence",
  "Quantum Machine Learning",
  "EEG Biometrics",
  "Cybersecurity",
  "Agentic AI",
  "Digital Twins",
  "Smart Cities",
  "Computer Vision",
  "IoT",
  "Human-Centered AI",
];

export const ACHIEVEMENTS = [
  {
    title: "Samsung Solve for Tomorrow — Top 40",
    description:
      "Developed an AI-powered rehabilitation platform integrating computer vision, real-time vitals monitoring, and haptic feedback.",
  },
  {
    title: "Taylor & Francis Publication",
    description:
      "Published research on a hybrid quantum-classical model for wheat harvest classification, reaching 99.88% accuracy.",
  },
  {
    title: "WebSphere Hackathon — 3rd Place",
    description: "Built a disaster-management platform under hackathon time constraints.",
  },
  {
    title: "Student Coordinator, Hack4Health",
    description: "Organized a campus-wide hackathon with 400+ participants.",
  },
  {
    title: "Technical Seminar Speaker",
    description: "Presented a technical seminar on fog orchestration.",
  },
];

export const NAV_LINKS = [
  { label: "About", href: "#about" },
  { label: "Experience", href: "#experience" },
  { label: "Projects", href: "#projects" },
  { label: "Research", href: "#research" },
  { label: "Skills", href: "#skills" },
  { label: "Achievements", href: "#achievements" },
  { label: "Contact", href: "#contact" },
];
