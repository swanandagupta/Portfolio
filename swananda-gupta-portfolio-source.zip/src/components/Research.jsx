import SectionHeader from "./SectionHeader";
import SignalDivider from "./SignalDivider";
import { RESEARCH_INTERESTS } from "../data/content";

const CONTRIBUTIONS = [
  "Proposed a hybrid Riemannian + quantum learning framework for EEG identity recognition.",
  "Designed an identity-state disentanglement architecture to separate 'who' from 'what state' in brain signals.",
  "Compared classical manifold learning against quantum-enhanced classification across paradigms.",
  "Improved the robustness of EEG biometric authentication under cross-session variation.",
];

function ManifoldGraphic() {
  return (
    <svg viewBox="0 0 320 240" className="w-full h-auto" aria-hidden="true">
      <defs>
        <radialGradient id="glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#A78BFA" stopOpacity="0.25" />
          <stop offset="100%" stopColor="#A78BFA" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx="160" cy="120" r="110" fill="url(#glow)" />
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <ellipse
          key={i}
          cx="160"
          cy="120"
          rx={40 + i * 14}
          ry={18 + i * 6}
          fill="none"
          stroke="#5EEAD4"
          strokeOpacity={0.5 - i * 0.06}
          strokeWidth="1"
          transform={`rotate(${i * 12} 160 120)`}
        />
      ))}
      {[
        [90, 70],
        [210, 60],
        [230, 150],
        [110, 175],
        [160, 100],
        [70, 140],
      ].map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r={i === 4 ? 5 : 3} fill={i === 4 ? "#FFB454" : "#EAF0FB"} fillOpacity={i === 4 ? 1 : 0.6} />
      ))}
    </svg>
  );
}

export default function Research() {
  return (
    <section id="research" className="border-b border-line bg-panel/30">
      <SignalDivider variant="calm" color="#A78BFA" className="pt-6" />
      <div className="max-w-6xl mx-auto px-6 py-20">
        <SectionHeader
          eyebrow="Panel // Research"
          title="What I'm researching"
          description="Interests spanning identity, signal, and inference — where AI meets quantum-enhanced methods."
          color="#A78BFA"
        />

        <div className="grid lg:grid-cols-5 gap-10 items-start">
          <div className="lg:col-span-3 bg-panel border border-line rounded-xl p-8">
            <p className="font-mono text-xs uppercase tracking-wider text-violet mb-3">Current research title</p>
            <h3 className="font-display font-semibold text-xl text-ink leading-snug mb-6">
              Manifold-Aware Identity–State Disentanglement for Cross-Paradigm EEG Biometric Identification: A
              Riemannian and Quantum-Enhanced Comparative Study
            </h3>

            <p className="font-mono text-xs uppercase tracking-wider text-muted mb-3">Contributions</p>
            <ul className="space-y-2.5 mb-6">
              {CONTRIBUTIONS.map((c) => (
                <li key={c} className="text-sm text-ink/80 leading-relaxed flex gap-2">
                  <span className="text-violet mt-1.5 shrink-0">—</span>
                  {c}
                </li>
              ))}
            </ul>

            <div className="flex flex-wrap gap-2 pt-4 border-t border-line">
              {["EEG Biometrics", "Riemannian Geometry", "Variational Quantum Classifier", "Cross-Paradigm Generalization", "Deep Representation Learning"].map(
                (t) => (
                  <span
                    key={t}
                    className="font-mono text-[11px] uppercase tracking-wide px-2.5 py-1 rounded border border-violet/40 text-violet"
                  >
                    {t}
                  </span>
                )
              )}
            </div>
          </div>

          <div className="lg:col-span-2 flex flex-col gap-6">
            <div className="bg-panel border border-line rounded-xl p-6">
              <ManifoldGraphic />
            </div>
            <div>
              <p className="font-mono text-xs uppercase tracking-wider text-muted mb-3">Broader research interests</p>
              <div className="flex flex-wrap gap-2">
                {RESEARCH_INTERESTS.map((r) => (
                  <span key={r} className="text-sm text-ink/80 bg-panel border border-line rounded-full px-3 py-1.5">
                    {r}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
