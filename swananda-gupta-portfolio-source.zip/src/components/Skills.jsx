import SectionHeader from "./SectionHeader";
import SignalDivider from "./SignalDivider";
import { SKILLS } from "../data/content";

export default function Skills() {
  return (
    <section id="skills" className="border-b border-line">
      <SignalDivider variant="spiky" color="#FFB454" className="pt-6" />
      <div className="max-w-6xl mx-auto px-6 py-20">
        <SectionHeader eyebrow="Panel // Skills" title="What I work with" color="#FFB454" />

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {SKILLS.map((group) => (
            <div key={group.label} className="bg-panel border border-line rounded-xl p-6">
              <p className="font-mono text-xs uppercase tracking-wider text-amber mb-4">{group.label}</p>
              <div className="flex flex-wrap gap-2">
                {group.items.map((item) => (
                  <span key={item} className="text-sm text-ink/80 bg-panel2 border border-line rounded-md px-2.5 py-1">
                    {item}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
