import SectionHeader from "./SectionHeader";
import SignalDivider from "./SignalDivider";
import { COMPETENCIES, PROFILE } from "../data/content";

export default function About() {
  return (
    <section id="about" className="border-b border-line">
      <SignalDivider variant="calm" color="#5EEAD4" className="pt-6" />
      <div className="max-w-6xl mx-auto px-6 py-20">
        <SectionHeader eyebrow="Panel // About" title="A little about how I work" />

        <div className="grid md:grid-cols-5 gap-12">
          <p className="md:col-span-3 text-lg text-ink/90 leading-relaxed">{PROFILE.bio}</p>

          <div className="md:col-span-2">
            <p className="font-mono text-xs uppercase tracking-wider text-muted mb-4">Core competencies</p>
            <div className="flex flex-wrap gap-2">
              {COMPETENCIES.map((c) => (
                <span
                  key={c}
                  className="text-sm text-ink/80 bg-panel border border-line rounded-full px-3 py-1.5"
                >
                  {c}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
