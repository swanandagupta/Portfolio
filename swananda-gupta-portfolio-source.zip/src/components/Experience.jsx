import SectionHeader from "./SectionHeader";
import SignalDivider from "./SignalDivider";
import { DOMAIN, EXPERIENCE } from "../data/content";

export default function Experience() {
  return (
    <section id="experience" className="border-b border-line bg-panel/30">
      <SignalDivider variant="spiky" color="#5EEAD4" className="pt-6" />
      <div className="max-w-6xl mx-auto px-6 py-20">
        <SectionHeader
          eyebrow="Panel // Experience"
          title="Where I've worked"
          description="Roles spanning security operations, applied research, and enterprise software."
          color="#FFB454"
        />

        <ol className="relative border-l border-line ml-2">
          {EXPERIENCE.map((role, i) => {
            const d = DOMAIN[role.domain];
            return (
              <li key={i} className="relative pl-8 pb-14 last:pb-0">
                <span
                  className="absolute -left-[7px] top-1.5 w-3.5 h-3.5 rounded-full border-2 border-base"
                  style={{ backgroundColor: d.color }}
                  aria-hidden="true"
                />
                <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1 mb-2">
                  <span className="font-mono text-xs" style={{ color: d.color }}>
                    {role.period}
                  </span>
                  <span className="font-mono text-xs uppercase tracking-wider text-muted">{d.name}</span>
                </div>
                <h3 className="font-display font-semibold text-xl text-ink">{role.role}</h3>
                <p className="font-mono text-sm text-muted mb-3">{role.org}</p>
                <p className="text-ink/85 leading-relaxed mb-4 max-w-2xl">{role.summary}</p>
                <ul className="space-y-1.5 mb-4 max-w-2xl">
                  {role.details.map((line, j) => (
                    <li key={j} className="text-sm text-ink/70 leading-relaxed flex gap-2">
                      <span className="text-line mt-1.5 shrink-0">—</span>
                      {line}
                    </li>
                  ))}
                </ul>
                <div className="flex flex-wrap gap-2">
                  {role.tags.map((tag) => (
                    <span
                      key={tag}
                      className="font-mono text-[11px] uppercase tracking-wide px-2.5 py-1 rounded border"
                      style={{ borderColor: d.color + "55", color: d.color }}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </li>
            );
          })}
        </ol>
      </div>
    </section>
  );
}
