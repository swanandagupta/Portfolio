import { Activity } from "lucide-react";
import SectionHeader from "./SectionHeader";
import SignalDivider from "./SignalDivider";
import { DOMAIN, PROJECTS } from "../data/content";

export default function Projects() {
  return (
    <section id="projects" className="border-b border-line">
      <SignalDivider variant="stepped" color="#A78BFA" className="pt-6" />
      <div className="max-w-6xl mx-auto px-6 py-20">
        <SectionHeader
          eyebrow="Panel // Projects"
          title="Things I've built"
          description="Systems that read a signal — network traffic, urban risk, sensor data — and act on it."
          color="#A78BFA"
        />

        <div className="grid sm:grid-cols-2 gap-5">
          {PROJECTS.map((p) => {
            const d = DOMAIN[p.domain];
            return (
              <article
                key={p.title}
                className="group bg-panel border border-line rounded-xl p-6 hover:border-cyan/40 transition-colors"
                style={{ borderTopColor: d.color, borderTopWidth: 2 }}
              >
                <div className="flex items-start justify-between gap-3 mb-3">
                  <h3 className="font-display font-semibold text-lg text-ink">{p.title}</h3>
                  <span className="font-mono text-[10px] uppercase tracking-wider text-muted shrink-0 mt-1.5">
                    {d.name}
                  </span>
                </div>

                <p className="text-sm text-ink/75 leading-relaxed mb-4">{p.description}</p>

                {p.highlights && (
                  <ul className="mb-4 space-y-1">
                    {p.highlights.map((h) => (
                      <li key={h} className="text-xs text-ink/60 flex gap-2 items-start">
                        <span className="text-line mt-0.5">·</span>
                        {h}
                      </li>
                    ))}
                  </ul>
                )}

                <div className="flex items-center gap-2 mb-4 font-mono text-xs" style={{ color: d.color }}>
                  <Activity size={13} />
                  {p.impact}
                </div>

                <div className="flex flex-wrap gap-2 pt-4 border-t border-line">
                  {p.tags.map((tag) => (
                    <span key={tag} className="font-mono text-[11px] text-muted">
                      {tag}
                      {tag !== p.tags[p.tags.length - 1] && <span className="text-line ml-2">/</span>}
                    </span>
                  ))}
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
