import { ArrowUpRight } from "lucide-react";
import SignalDivider from "./SignalDivider";
import { GithubIcon, LinkedinIcon } from "./Icons";
import { PROFILE } from "../data/content";

export default function Contact() {
  return (
    <section id="contact">
      <SignalDivider variant="stepped" color="#5EEAD4" className="pt-6" />
      <div className="max-w-6xl mx-auto px-6 py-24">
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-cyan mb-4">Panel // Contact</p>
        <h2 className="font-display font-semibold text-4xl sm:text-5xl text-ink tracking-tight max-w-2xl mb-6">
          Let's talk signal
        </h2>
        <p className="text-muted max-w-xl mb-10 leading-relaxed">
          Open to roles and collaborations in AI, cybersecurity, and full-stack engineering. The fastest way to reach
          me is LinkedIn — or take a look at what I've shipped on GitHub.
        </p>

        <div className="flex flex-wrap gap-4">
          <a
            href={PROFILE.links.linkedin}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3.5 rounded-md bg-cyan text-base font-mono text-sm uppercase tracking-wider hover:brightness-110 transition"
          >
            <LinkedinIcon size={16} />
            Connect on LinkedIn
            <ArrowUpRight size={15} />
          </a>
          <a
            href={PROFILE.links.github}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3.5 rounded-md border border-line text-ink font-mono text-sm uppercase tracking-wider hover:border-cyan/50 hover:text-cyan transition"
          >
            <GithubIcon size={16} />
            View GitHub
            <ArrowUpRight size={15} />
          </a>
        </div>
      </div>
    </section>
  );
}
