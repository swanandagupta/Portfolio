import { ArrowDown } from "lucide-react";
import LiveSignal from "./LiveSignal";
import { GithubIcon, LinkedinIcon } from "./Icons";
import { PROFILE } from "../data/content";

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden border-b border-line">
      <div className="absolute inset-0 bg-grid bg-grid opacity-40" />
      <div className="relative h-32 sm:h-40">
        <LiveSignal />
      </div>

      <div className="max-w-6xl mx-auto px-6 pb-20 pt-6 relative">
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-cyan mb-6">
          Signal // 01 · {PROFILE.affiliation}
        </p>

        <h1 className="font-display font-semibold text-5xl sm:text-7xl leading-[1.02] tracking-tight text-ink max-w-4xl">
          {PROFILE.name}
        </h1>

        <p className="mt-6 max-w-2xl text-lg sm:text-xl text-muted leading-relaxed">
          {PROFILE.tagline}
        </p>

        <div className="mt-8 flex flex-wrap gap-2">
          {PROFILE.focus.map((f) => (
            <span
              key={f}
              className="font-mono text-xs uppercase tracking-wider text-ink/80 border border-line rounded-full px-3 py-1"
            >
              {f}
            </span>
          ))}
        </div>

        <div className="mt-10 flex flex-wrap items-center gap-4">
          <a
            href="#projects"
            className="inline-flex items-center gap-2 px-5 py-3 rounded-md bg-cyan text-base font-mono text-sm uppercase tracking-wider hover:brightness-110 transition"
          >
            See the work
            <ArrowDown size={15} />
          </a>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 px-5 py-3 rounded-md border border-line text-ink font-mono text-sm uppercase tracking-wider hover:border-cyan/50 hover:text-cyan transition"
          >
            Contact
          </a>

          <div className="flex items-center gap-3 ml-auto">
            <a
              href={PROFILE.links.github}
              target="_blank"
              rel="noreferrer"
              aria-label="GitHub profile"
              className="w-10 h-10 grid place-items-center rounded-md border border-line text-muted hover:text-cyan hover:border-cyan/50 transition"
            >
              <GithubIcon size={18} />
            </a>
            <a
              href={PROFILE.links.linkedin}
              target="_blank"
              rel="noreferrer"
              aria-label="LinkedIn profile"
              className="w-10 h-10 grid place-items-center rounded-md border border-line text-muted hover:text-cyan hover:border-cyan/50 transition"
            >
              <LinkedinIcon size={18} />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
