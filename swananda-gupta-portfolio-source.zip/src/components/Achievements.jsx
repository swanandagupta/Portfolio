import { Award } from "lucide-react";
import SectionHeader from "./SectionHeader";
import SignalDivider from "./SignalDivider";
import { ACHIEVEMENTS } from "../data/content";

export default function Achievements() {
  return (
    <section id="achievements" className="border-b border-line bg-panel/30">
      <SignalDivider variant="calm" color="#5EEAD4" className="pt-6" />
      <div className="max-w-6xl mx-auto px-6 py-20">
        <SectionHeader eyebrow="Panel // Achievements" title="Recognition & milestones" />

        <div className="grid sm:grid-cols-2 gap-5">
          {ACHIEVEMENTS.map((a) => (
            <div key={a.title} className="flex gap-4 bg-panel border border-line rounded-xl p-6">
              <span className="w-9 h-9 rounded-md bg-panel2 border border-line grid place-items-center shrink-0 text-cyan">
                <Award size={16} />
              </span>
              <div>
                <h3 className="font-display font-semibold text-ink mb-1.5">{a.title}</h3>
                <p className="text-sm text-ink/70 leading-relaxed">{a.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
