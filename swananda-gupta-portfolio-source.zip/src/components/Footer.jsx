export default function Footer() {
  return (
    <footer className="border-t border-line">
      <div className="max-w-6xl mx-auto px-6 py-8 flex flex-col sm:flex-row items-center justify-between gap-3">
        <p className="font-mono text-xs text-muted">© {new Date().getFullYear()} Swananda Gupta</p>
        <p className="font-mono text-xs text-muted">Built with React &amp; Tailwind</p>
      </div>
    </footer>
  );
}
